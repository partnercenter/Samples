﻿using TechData.API.Service.Interface;

namespace TechData.API.Service.StreamOne
{
    public class OfferService:IOfferService
    {      
        public string GetOffers()
        {              
            return "from Stream One";
        }
    }
}
