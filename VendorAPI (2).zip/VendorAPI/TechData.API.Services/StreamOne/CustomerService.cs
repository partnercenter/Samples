﻿using System;
using TechData.API.Service.Interface;

namespace TechData.API.Service.StreamOne
{
    public class CustomerService:ICustomerService
    {
        public void CreateCustomer()
        {

            throw new NotImplementedException();
        }
    }
}
