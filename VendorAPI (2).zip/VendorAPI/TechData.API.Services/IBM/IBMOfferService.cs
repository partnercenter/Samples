﻿
using System;
using Microsoft.Store.PartnerCenter.Models;
using Microsoft.Store.PartnerCenter.Models.Offers;
using TechData.API.Service.Interface;

namespace TechData.API.Service.IBM
{
    public class IBMOfferService : IOfferService
    {
        public string GetOffers()
        {
            return "from IBM";
        }
    }
}
