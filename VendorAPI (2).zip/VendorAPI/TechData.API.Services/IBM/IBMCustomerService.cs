﻿using System;
using TechData.API.Service.Interface;

namespace TechData.API.Service.IBM
{
    public class IBMCustomerService : ICustomerService
    {
        public void CreateCustomer()
        {
            throw new NotImplementedException();
        }
    }
}
