﻿using System;
using Microsoft.Store.PartnerCenter.Models;
using Microsoft.Store.PartnerCenter.Models.Offers;
using TechData.API.Service.Interface;

namespace TechData.API.Service.Microsoft
{
    public class MicrosoftOfferService : IOfferService
    {
        public string GetOffers()
        {
            return "from Microsoft";
        }
    }
}
