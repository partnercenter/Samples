﻿using System;
using TechData.API.Service.Interface;

namespace TechData.API.Service.Microsoft
{
    public class MicroSoftCustomerService : ICustomerService
    {
        public void CreateCustomer()
        {
            throw new NotImplementedException();
        }

    }
}
