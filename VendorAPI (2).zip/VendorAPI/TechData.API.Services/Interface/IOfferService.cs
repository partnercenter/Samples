﻿
namespace TechData.API.Service.Interface
{
    public interface IOfferService
    {
        string GetOffers();
    }
}
