﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TechData.API.VendorAPI.Controllers.Offer;

namespace VendorAPI.Tests.Controllers
{
    [TestClass]
    public class OfferControllerTest
    {
       
        [TestMethod]
        public void Get()
        {

            // Arrange
            OfferController controller = new OfferController();

            // Act
            var result = controller.GetOffers();

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(200, result.StatusCode.ToString());
            Assert.AreEqual("from Stream One", result.Content.ReadAsStringAsync());
            
        }

        //[TestMethod]
        //public void GetById()
        //{
        //    ICustomerRepository customerRepository = new MSCustomerRepository();
        //    ICustomerProvider customerProvider = new CustomerProvider(customerRepository);
        //    // Arrange
        //    ValuesController controller = new ValuesController(customerProvider);

        //    // Act
        //    string result = controller.Get(5);

        //    // Assert
        //    Assert.AreEqual("value", result);
        //}

        //[TestMethod]
        //public void Post()
        //{
        //    ICustomerRepository customerRepository = new MSCustomerRepository();
        //    ICustomerProvider customerProvider = new CustomerProvider(customerRepository);
        //    // Arrange
        //    ValuesController controller = new ValuesController(customerProvider);

        //    // Act
        //    controller.Post("value");

        //    // Assert
        //}

        //[TestMethod]
        //public void Put()
        //{
        //    ICustomerRepository customerRepository = new MSCustomerRepository();
        //    ICustomerProvider customerProvider = new CustomerProvider(customerRepository);
        //    // Arrange
        //    ValuesController controller = new ValuesController(customerProvider);

        //    // Act
        //    controller.Put(5, "value");

        //    // Assert
        //}

        //[TestMethod]
        //public void Delete()
        //{
        //    ICustomerRepository customerRepository = new MSCustomerRepository();
        //    ICustomerProvider customerProvider = new CustomerProvider(customerRepository);
        //    // Arrange
        //    ValuesController controller = new ValuesController(customerProvider);

        //    // Act
        //    controller.Delete(5);

        //    // Assert
        //}
    }
}
