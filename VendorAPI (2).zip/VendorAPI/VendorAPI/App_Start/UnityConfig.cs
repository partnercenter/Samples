using Microsoft.Practices.Unity;
using System.Web.Http;
using Unity.WebApi;
using Microsoft.Practices.ServiceLocation;

namespace TechData.API.VendorAPI
{
    public static class UnityConfig
    {

        public static void RegisterComponents()
        {

            // register all your components with the container here
            // it is NOT necessary to register your controllers

            UnityServiceLocator locator = new UnityServiceLocator(ConfigureUnityContainer());
            ServiceLocator.SetLocatorProvider(() => locator);

        }

        private static IUnityContainer ConfigureUnityContainer()
        {
            UnityContainer container = new UnityContainer();

            using (var contrainer = new UnityContainer())
            {
                container.RegisterInstance<IServiceLocator>(new UnityServiceLocator(container), new ExternallyControlledLifetimeManager());
            }

            // register all your components with the container here
            // it is NOT necessary to register your controllers         


            Microsoft.Practices.Unity.Configuration.UnityContainerExtensions.LoadConfiguration(container, "extras");      

            GlobalConfiguration.Configuration.DependencyResolver = new UnityDependencyResolver(container);

            return container;
        }

}
}