using Microsoft.Practices.Unity;
using System.Web.Http;
using Unity.WebApi;
using Microsoft.Practices.ServiceLocation;
using TechData.API.Service.Interface;
using TechData.API.Service.StreamOne;
using TechData.API.Service.Microsoft;
using TechData.API.Service.IBM;

namespace TechData.API.VendorAPI
{
    public static class UnityConfig
    {

        public static void RegisterComponents()
        {

            // register all your components with the container here
            // it is NOT necessary to register your controllers

            UnityServiceLocator locator = new UnityServiceLocator(ConfigureUnityContainer());
            ServiceLocator.SetLocatorProvider(() => locator);

        }

        private static IUnityContainer ConfigureUnityContainer()
        {
            UnityContainer container = new UnityContainer();

            using (var contrainer = new UnityContainer())
            {
                container.RegisterInstance<IServiceLocator>(new UnityServiceLocator(container), new ExternallyControlledLifetimeManager());
            }

            // register all your components with the container here
            // it is NOT necessary to register your controllers
            container.RegisterType<IOfferService, OfferService>(new ContainerControlledLifetimeManager());           
            container.RegisterType<IOfferService, IBMOfferService>("IBM",new ContainerControlledLifetimeManager());
            container.RegisterType<IOfferService, MicrosoftOfferService>("MS", new ContainerControlledLifetimeManager());


            container.RegisterType<ICustomerService, CustomerService>(new ContainerControlledLifetimeManager());
            container.RegisterType<ICustomerService, IBMCustomerService>("IBM", new ContainerControlledLifetimeManager());
            container.RegisterType<ICustomerService, MicroSoftCustomerService>("MS", new ContainerControlledLifetimeManager());


            Microsoft.Practices.Unity.Configuration.UnityContainerExtensions.LoadConfiguration(container, "extras");      

            GlobalConfiguration.Configuration.DependencyResolver = new UnityDependencyResolver(container);

            return container;
        }

}
}