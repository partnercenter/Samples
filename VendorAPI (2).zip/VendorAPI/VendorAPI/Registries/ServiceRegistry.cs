﻿using Microsoft.Practices.Unity;

namespace TechData.API.VendorAPI.Registries
{
    public class ServiceRegistry : UnityContainerExtension
    {        
        protected override void Initialize()
        {
                      
        }
    }
}