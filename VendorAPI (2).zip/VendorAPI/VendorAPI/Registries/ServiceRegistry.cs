﻿using Microsoft.Practices.Unity;
using TechData.API.Service.Interface;
using TechData.API.Service.StreamOne;
using TechData.API.Service.Microsoft;
using TechData.API.Service.IBM;

namespace TechData.API.VendorAPI.Registries
{
    public class ServiceRegistry : UnityContainerExtension
    {        
        protected override void Initialize()
        {
            if (!Container.IsRegistered<ICustomerService>())
            {
                Container.RegisterType<ICustomerService, CustomerService>();
            }
        
            if (!Container.IsRegistered<IOfferService>())
            {
                Container.RegisterType<IOfferService, OfferService>();
            }          

           
        }
    }
}