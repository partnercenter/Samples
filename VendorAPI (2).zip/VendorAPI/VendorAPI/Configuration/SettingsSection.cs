﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TechData.API.VendorAPI.Configuration
{
    /// <summary>
    /// Holds the scenario specific settings section.
    /// </summary>
    public class SettingsSection:Section
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="ScenarioSettingsSection"/> class.
        /// </summary>
        public SettingsSection() : base("VendorSettings")
        {
        }

        /// <summary>
        /// Gets the customer domain suffix.
        /// </summary>
        public string CustomerDomainSuffix
        {
            get
            {
                return ConfigurationSection["CustomerDomainSuffix"];
            }
        }

        /// <summary>
        /// Gets the ID of the customer to delete from the TIP account.
        /// </summary>
        public string CustomerIdToDelete
        {
            get
            {
                return ConfigurationSection["CustomerIdToDelete"];
            }
        }

        /// <summary>
        /// Gets the ID of the customer whose details should be read.
        /// </summary>
        public string DefaultCustomerId
        {
            get
            {
                return ConfigurationSection["DefaultCustomerId"];
            }
        }

        /// <summary>
        /// Gets the number of customers to return in each customer page.
        /// </summary>
        public int CustomerPageSize
        {
            get
            {
                return int.Parse(ConfigurationSection["CustomerPageSize"]);
            }
        }

        /// <summary>
        /// Gets the number of offers to return in each offer page.
        /// </summary>
        public int DefaultOfferPageSize
        {
            get
            {
                return int.Parse(ConfigurationSection["DefaultOfferPageSize"]);
            }
        }

        /// <summary>
        /// Gets the number of invoices to return in each invoice page.
        /// </summary>
        public int InvoicePageSize
        {
            get
            {
                return int.Parse(ConfigurationSection["InvoicePageSize"]);
            }
        }

        /// <summary>
        /// Gets the configured Invoice ID.
        /// </summary>
        public string DefaultInvoiceId
        {
            get
            {
                return ConfigurationSection["DefaultInvoiceId"];
            }
        }

        /// <summary>
        /// Gets the configured partner MPD ID.
        /// </summary>
        public string PartnerMpnId
        {
            get
            {
                return ConfigurationSection["PartnerMpnId"];
            }
        }

        /// <summary>
        /// Gets the configured offer ID.
        /// </summary>
        public string DefaultOfferId
        {
            get
            {
                return ConfigurationSection["DefaultOfferId"];
            }
        }

        /// <summary>
        /// Gets the configured order ID.
        /// </summary>
        public string DefaultOrderId
        {
            get
            {
                return ConfigurationSection["DefaultOrderId"];
            }
        }

        /// <summary>
        /// Gets the configured subscription ID.
        /// </summary>
        public string DefaultSubscriptionId
        {
            get
            {
                return ConfigurationSection["DefaultSubscriptionId"];
            }
        }

        /// <summary>
        /// Gets the service request ID.
        /// </summary>
        public string DefaultServiceRequestId
        {
            get
            {
                return ConfigurationSection["DefaultServiceRequestId"];
            }
        }

        /// <summary>
        /// Gets the number of service requests to return in each service request page.
        /// </summary>
        public int ServiceRequestPageSize
        {
            get
            {
                return int.Parse(ConfigurationSection["ServiceRequestPageSize"]);
            }
        }

        /// <summary>
        /// Gets the configured support topic ID for creating new service request.
        /// </summary>
        public string DefaultSupportTopicId
        {
            get
            {
                return ConfigurationSection["DefaultSupportTopicId"];
            }
        }
    }
}