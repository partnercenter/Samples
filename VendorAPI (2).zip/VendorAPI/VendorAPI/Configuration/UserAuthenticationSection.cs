﻿using System;
namespace TechData.API.VendorAPI.Configuration
{
    /// <summary>
    /// Holds a user authentication section settings.
    /// </summary>
    public class UserAuthenticationSection:Section
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UserAuthenticationSection"/> class.
        /// </summary>
        /// <param name="sectionName">The application authentication section name.</param>
        public UserAuthenticationSection(string sectionName) : base(sectionName)
        {
        }

        /// <summary>
        /// Gets the AAD application ID.
        /// </summary>
        public string ApplicationId
        {
            get
            {
                return ConfigurationSection["ApplicationId"];
            }
        }

        /// <summary>
        /// Gets the resource the application is attempting to access, i.e. the partner API service.
        /// </summary>
        public Uri ResourceUrl
        {
            get
            {
                return new Uri(ConfigurationSection["ResourceUrl"]);
            }
        }

        /// <summary>
        /// Gets the application redirect URL.
        /// </summary>
        public Uri RedirectUrl
        {
            get
            {
                return new Uri(ConfigurationSection["RedirectUrl"]);
            }
        }

        /// <summary>
        /// Gets AAD user name.
        /// </summary>
        public string UserName
        {
            get
            {
                return ConfigurationSection["UserName"];
            }
        }

        /// <summary>
        /// Gets AAD password.
        /// </summary>
        public string Password
        {
            get
            {
                return ConfigurationSection["Password"];
            }
        }
    }
}