﻿
using System.Web.Http;
using System.Net.Http;
using log4net;
using System.Net;
using Microsoft.Practices.ServiceLocation;

namespace TechData.API.VendorAPI.Controllers.Offer
{
    public class OfferController: ApiController
    {       
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        [Route("api/offers")]
        [HttpGet]
        public HttpResponseMessage GetOffers()
        {  
            return Request.CreateResponse(HttpStatusCode.OK, "testOffers");
        }

        [Route("api/offers/id")]
        [HttpGet]
        public HttpResponseMessage GetOffers(string offerID)
        {
            return Request.CreateResponse("testOfferID");
        }
    }
}