﻿using log4net;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Microsoft.Practices.ServiceLocation;
using Microsoft.Store.PartnerCenter;
using Microsoft.Store.PartnerCenter.Extensions;
using MSModels= Microsoft.Store.PartnerCenter.Models;
using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;


namespace TechData.API.VendorAPI.Controllers.Customer
{
    public class CustomerController:ApiController
    {
       
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public object PartnerUserConfiguration { get; private set; }

        [HttpGet]
        public System.Net.Http.HttpResponseMessage Customer()
        {
            Log.Debug("GET Request traced in Log");       
            return Request.CreateResponse("test");
        }

        [Route("api/customers")]
        [HttpGet]
        public HttpResponseMessage GetCustomers()
        {
    
            var customerResult = GetCustomersWithUserCredentials();
            return Request.CreateResponse< MSModels.SeekBasedResourceCollection<MSModels.Customers.Customer>>(HttpStatusCode.OK, customerResult);
        }

        public static MSModels.SeekBasedResourceCollection<MSModels.Customers.Customer> GetCustomersWithUserCredentials()
        {
            IAggregatePartner partner = GetPartnerCenterTokenWithUserCredentials();
            // get customer list
            var customers = partner.Customers.Get();
            return customers;
        }

        /// <summary>
        /// Gets the partner center token using the managed API.
        /// </summary>
        /// <returns>Partner Center SDK partner interface</returns>
        public static IAggregatePartner GetPartnerCenterTokenWithUserCredentials()
        {

            VendorAPI.Configuration.PartnerServiceSettingsSection partnerSetting = new VendorAPI.Configuration.PartnerServiceSettingsSection();
            VendorAPI.Configuration.UserAuthenticationSection userAuthenticationSetting = new VendorAPI.Configuration.UserAuthenticationSection("UserAuthentication");

            // Get a user Azure AD Token
            var aadAuthResult = UserLogin();
            PartnerService.Instance.ApiRootUrl = partnerSetting.PartnerServiceApiEndpoint.ToString();
            var partnerCredentials = PartnerCredentials.Instance.GenerateByUserCredentials(userAuthenticationSetting.ApplicationId, new AuthenticationToken(aadAuthResult.AccessToken, aadAuthResult.ExpiresOn), async delegate
            {
                // Token Refresh callback
                aadAuthResult = UserLogin();
                return await Task.FromResult<AuthenticationToken>(new AuthenticationToken(aadAuthResult.AccessToken, aadAuthResult.ExpiresOn));
            });

            // get operation with partnerCredentials
            return PartnerService.Instance.CreatePartnerOperations(partnerCredentials);
        }

        /// <summary>
        /// Sign the user into Azure AD and get token.
        /// </summary>
        /// <returns>user token</returns>
        public static AuthenticationResult UserLogin()
        {
            VendorAPI.Configuration.PartnerServiceSettingsSection partnerSetting = new VendorAPI.Configuration.PartnerServiceSettingsSection();
            VendorAPI.Configuration.UserAuthenticationSection userAuthenticationSetting = new VendorAPI.Configuration.UserAuthenticationSection("UserAuthentication");

            var addAuthority = new UriBuilder(partnerSetting.AuthenticationAuthorityEndpoint)
            {
                Path = partnerSetting.CommonDomain
            };

            UserCredential userCredentials = new UserCredential(userAuthenticationSetting.UserName, userAuthenticationSetting.Password);
            AuthenticationContext authContext = new AuthenticationContext(addAuthority.Uri.AbsoluteUri);

          
            var authResult= authContext.AcquireTokenAsync(userAuthenticationSetting.ResourceUrl.OriginalString, userAuthenticationSetting.ApplicationId, userCredentials).Result;

            return authResult;
        }

      
    }

    
}